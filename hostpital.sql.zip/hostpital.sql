-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 17, 2015 at 01:47 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `hostpital`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `apointment`
-- 

CREATE TABLE `apointment` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `age` int(10) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `tel` int(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` varchar(14) NOT NULL,
  `humain` varchar(50) NOT NULL,
  `nature` mediumtext NOT NULL,
  `dob` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `apointment`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `contatc`
-- 

CREATE TABLE `contatc` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `phone` int(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `comment` varchar(50000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `contatc`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `patient_tb`
-- 

CREATE TABLE `patient_tb` (
  `patient_id` int(11) NOT NULL auto_increment,
  `pname` varchar(100) NOT NULL,
  `regno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `test` varchar(500) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `passport` varchar(50) NOT NULL,
  `dob` varchar(100) NOT NULL,
  PRIMARY KEY  (`patient_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `patient_tb`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `users`
-- 

